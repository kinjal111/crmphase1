import React, { Component, Fragment } from 'react';
import {
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  TouchableHighlight,
  TextInput,
  SafeAreaView,
  Switch,
  ImageBackground,
  Alert,
  Keyboard

} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Overlay } from 'react-native-elements';
import SectionedMultiSelect from 'react-native-sectioned-multi-select';
import { textHeader, font_style, textInput } from '../components/styles';
import HeaderBackground from '../components/HeaderBackground'
import Constant from '../constants/Constant'
import Colors from '../constants/Colors';
import { Dropdown } from 'react-native-material-dropdown'
import TagInput from 'react-native-tags-input';
import { apiBasePath } from '../constantApi';
import FlashMessage, { showMessage } from "react-native-flash-message";
import NetworkUtils from '../components/NetworkUtils';



// Define the default value of tabvalue

const tabvalue = 0;

export default class AccountSettingsSecondScreen extends React.PureComponent {

  // Display Header and It's elements and functionality of header elements 

  static navigationOptions = ({ navigation }) => ({

    headerBackground: () => <HeaderBackground />,

    headerTitle: () => <Text style={textHeader.header}>{Constant.contact_profile}</Text>,

    headerLeft: () =>

      <View style={{ flexDirection: 'row' }}>

        <TouchableOpacity style={[styles.top_layout1]} activeOpacity={1}
          onPress={() => { navigation.goBack(null) }} >

          <Image source={require('./../assets/images/arrow-left.png')}
            style={{ width: 20, height: 20, }} resizeMode="contain" />

        </TouchableOpacity>

        <TouchableOpacity style={[styles.top_layout1], { paddingTop: 5, flex: 0.6 }} activeOpacity={1}
          onPress={() => { navigation.toggleDrawer(), Keyboard.dismiss() }}>

          <Image source={require('./../assets/images/menu_3x.png')}
            style={{ width: 20, height: 20, }} resizeMode="contain" />

        </TouchableOpacity>

      </View>,

    headerRight: () =>

      <TouchableOpacity style={styles.top_layout} activeOpacity={1}
        onPress={() => { navigation.getParam('saveContactDetail')(); }} >

        <Text style={[{ color: Colors.white_color, fontSize: 16, textAlign: 'center' }, font_style.font_medium]}>Save</Text>

      </TouchableOpacity>,

  });


  // Initilize the State variable 

  constructor() {
    super();

    this.state = {
      selectedButton: 'EditProfile',
      isvisible: false,
      set_main: 0,
      setmainTogglevalue: 0,
      receiveMarketingToggleValue: 0,
      isLoading: true,
      select_industry: '',
      contact_categ: '',
      contact_id: '',
      company_id: '',
      contact_Data: '',
      ProfileData: '',
      subContactData: '',
      subContactState: false,
      subContact_id: '',
      subContactDetail: '',
      tags: {
        tag: '',
        tagsArray: ['Book','Product']
      },
      subtags: {
        tag: '',
        tagsArray: []
      },
      // tagsArray:'',
      isTag:false,
      title: '',
      firstname: '',
      lastname: '',
      office_no: '',
      extention_no: '',
      mobile_no: '',
      home_no: '',
      Country: '',
      email: '',
      address: '',
      city: '',
      state: '',
      recieveMarketing: 0,
      postal_code: '',
      company_name: '',
      designation: '',
      product_services: '',
      remarks: '',
      website: '',
      sub_firstname: '',
      sub_lastname: '',
      sub_title: '',
      sub_office_no: '',
      sub_extention_no: '',
      sub_home_no: '',
      sub_address: '',
      subcity: '',
      subState: '',
      subemail: '',
      sub_postal_code: '',
      sub_company_name: '',
      sub_designation: '',
      sub_product_services: '',
      select_title: '',
      select_sub_industry: '',
      select_sub_designation: '',
      select_sub_country: '',
      sub_remarks: '',
      sub_website: '',
      DataState: false,
      selectedTab: 0,
      switchValue: false,
      selectedItems: [],
      deal_amount_open: '',
      feature_comming_Soon: false,
      feature_name: '',

    }
  }

  // set the selected tags in tags variable to update the Tags of Contact

  updateTagState = (state) => {

    this.setState({ tags: state });
    console.warn("Tags..",this.state.tags);

  };

  // set the selected tags in subtags variable to update the Tags of sub Contact

  updateSubTagState = (state) => {

    this.setState({ subtags: state })

  };

  // get the Default Data for Calling api method init and then change the key or structure of Data to make dropdown supported by cll modify keys

  componentDidMount = async () => {
    const { navigation } = this.props
    navigation.setParams({ saveContactDetail: this.saveContactDetail });

    let Contact_id = this.props.navigation.getParam('contactID')
    let Company_id = this.props.navigation.getParam('companyID')
    let Contact_category = this.props.navigation.getParam('contact_type')


    this.setState({ contact_id: Contact_id, company_id: Company_id, contact_categ: Contact_category })

    const isConnected = await NetworkUtils.isNetworkAvailable()

    if (isConnected) {

      const api_token = await AsyncStorage.getItem(Constant.api_token);
      let formData = new FormData();

      formData.append('api_token', api_token);
      formData.append('api_key', 'b4bc8f195a1c926b184f33a466bbc837689b33fe');
      formData.append('method', 'init');

      fetch(apiBasePath, {
        method: 'POST',
        body: formData
      })

        .then(response => {
          if (response.status == 200) {

            return response.json();
          }
          else if (response.status == 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }
          else {

          }

        })
        .then(responseJson => {
          str = responseJson;


          if (str.error === 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }
          else {
            this.setState({ industry: str.contact_industries, title: str.contact_titles, Country: str.countries, designation: str.contact_designations, DataState: true }, () => { this.modifyKeys() });
          }
        })
        .catch(error => {

          this.setState({ isLoading: false }, () => { });
        }
        )
    }
    else {

      alert('Check Your Internet Connection and Try Again')

    }
  }

  // modify the Keys of and structure of object for make supporting Input Data for Dropdown 

  modifyKeys() {

    var y = []
    var industryItem = this.state.industry;
    industryItem.map((cv) => {
      var z = {}

      if (z.value === undefined) {
        z.value = cv
        y.push(z)
      }

      this.setState({ industry: y })

    })



    var x = []
    var titleItem = this.state.title;
    titleItem.map((cv) => {
      var z = {}

      if (z.value === undefined) {
        z.value = cv
        x.push(z)
      }

      this.setState({ title: x })

    })

    var s = []
    var countryItem = this.state.Country;
    countryItem.map((cv) => {
      var z = {}

      if (z.value === undefined) {
        z.value = cv
        s.push(z)
      }

      this.setState({ Country: s })

    })

    var t = []
    var designationItem = this.state.designation;
    designationItem.map((cv) => {
      var z = {}

      if (z.value === undefined) {
        z.value = cv
        t.push(z)
      }

      this.setState({ designation: t },
        () => { this.getContactProfileDetail() })
    })
  }

  // get the Contact Detail Of Contact which is selected in Contact List of Call list Page and set the default value of field of contact profile

  getContactProfileDetail = async () => {

    const isConnected = await NetworkUtils.isNetworkAvailable()

    if (isConnected) {

      const api_token = await AsyncStorage.getItem(Constant.api_token);
      let formData = new FormData();

      formData.append('api_key', 'b4bc8f195a1c926b184f33a466bbc837689b33fe');
      formData.append('api_token', api_token);
      formData.append('method', 'get_contact_profile_details');
      formData.append('contact_id', this.state.contact_id);

      fetch(apiBasePath, {
        method: 'POST',
        body: formData
      })

        .then(response => {
          if (response.status == 200) {

            return response.json();
          }
          else if (response.status == 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }
          else {

          }

        })
        .then(responseJson => {
          str = responseJson;
           console.warn("String Contact Profile",str);
           console.warn("TAGS...",this.state.tags)
          if (str.error == 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }
          else {
            this.setState({ isLoading: false, ProfileData: str, select_title: str.title, firstname: str.first_name, lastname: str.last_name, office_no: str.office_number, extention_no: str.ext_number, mobile_no: str.mobile_number, home_no: str.home_number, email: str.email, address: str.address, city: str.city, state: str.state, postal_code: str.postal_code, website: str.website, company: str.company_name, deal_amount_open: str.deal_amount_open, select_industry: str.industry, select_designation: str.designation, select_country: str.country,remarks:str.remarks, recieveMarketing: str.receive_telemktg });
//           console.warn("Tags",str.products_services);
          let val=str.products_services;
          let ar = val.split(','); // split string on comma space
          console.warn("arrr", ar);
    this.state.tags.tagsArray=ar;
    console.warn("TAGA Array",this.state.tags)
    console.warn("TAGA Array",this.state.tags.tagsArray.length)
//           let value=ar.toString();
         
// var arr1 = this.state.tags;
// var arr2 = arr1.tagsArray;
// arr2.push(value);
// //arr2 = value;
// arr1.tagsArray = arr2;
// console.warn("arr1 =================== : " , arr1);
// this.setState({tags:arr1})
 
          }
        })
        .catch(error => {

          this.setState({ isLoading: false, });
        }
        )
    }

    else {

      alert('Check Your Internet Connection and Try Again')

    }
  }

  // Get the List of SubContacts of Contact by callig api Method get_sub_contacts

  getSubContact = async () => {

    const isConnected = await NetworkUtils.isNetworkAvailable()

    if (isConnected) {

      const api_token = await AsyncStorage.getItem(Constant.api_token);

      let formData = new FormData();

      formData.append('api_key', 'b4bc8f195a1c926b184f33a466bbc837689b33fe');
      formData.append('api_token', api_token);
      formData.append('method', 'get_sub_contacts');
      formData.append('company_id', this.state.company_id);
      formData.append('contact_id', this.state.contact_id);

      fetch(apiBasePath, {
        method: 'POST',
        body: formData
      })

        .then(response => {
          if (response.status == 200) {

            return response.json();
          }
          else if (response.status == 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }
          else {

          }

        })
        .then(responseJson => {
          str = responseJson;

          if (str.error == 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }
          else {
            this.setState({ isLoading: false, subContactData: str, }, () => {
              this.modifySubContactKey()
            });
          }


        })
        .catch(error => {

          this.setState({ isLoading: false }, () => { });
        }
        )
    }
    else {

      alert('Check Your Internet Connection and Try Again')

    }
  }

  // Get the Detail of SubContact by calling api method get_sub_contact_details and set the default vaue of field of sub Contact Field

  getSubContactDetails = async () => {

    const isConnected = await NetworkUtils.isNetworkAvailable()

    if (isConnected) {

      const api_token = await AsyncStorage.getItem(Constant.api_token);
      let formData = new FormData();

      formData.append('api_key', 'b4bc8f195a1c926b184f33a466bbc837689b33fe');
      formData.append('api_token', api_token);
      formData.append('method', 'get_sub_contact_details');
      formData.append('sub_contact_id', this.state.subContact_id);


      fetch(apiBasePath, {
        method: 'POST',
        body: formData
      })

        .then(response => {
          if (response.status == 200) {
            return response.json();
          }
          else if (response.status == 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }
          else {
          }

        })
        .then(responseJson => {
          str = responseJson;

          if (str.error === 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }
          else {


            this.setState({ isLoading: false, subContactDetail: str, sub_title: str.title, sub_firstname: str.first_name, sub_lastname: str.last_name, sub_mobile_no: str.mobile_number, sub_home_no: str.home_number, sub_extention_no: str.ext_number, sub_postal_code: str.postal_code, subemail: str.email, sub_address: str.address, sub_company_name: str.company_name, sub_designation: str.designation, subcity: str.city, subState: str.state, sub_website: str.website, select_sub_Country: str.country, select_sub_industry: str.industry, select_sub_designation: str.designation });
          }
        })
        .catch(error => {

          this.setState({ isLoading: false }, () => { });
        }
        )
    }
    else {

      alert('Check Your Internet Connection and Try Again')

    }
  }

  // Update Contact Detail of Contact and Subcontact Depends upon the Selected Tab Of Contacts Or Subcontacts by calling api method update_main_contact or update_sub_contact respectively

  saveContactDetail = async () => {

    const isConnected = await NetworkUtils.isNetworkAvailable()

    if (isConnected) {

      if (this.state.selectedTab === 0) {

        const api_token = await AsyncStorage.getItem(Constant.api_token);
        let formData = new FormData();

        formData.append('api_key', 'b4bc8f195a1c926b184f33a466bbc837689b33fe');
        formData.append('api_token', api_token);
        formData.append('method', 'update_main_contact');
        formData.append('contact_type', this.state.contact_categ);
        formData.append('company_id', this.state.company_id);
        formData.append('contact_id', this.state.contact_id);
        formData.append('first_name', this.state.firstname);
        formData.append('last_name', this.state.lastname);
        formData.append('company_name', this.state.company);
        formData.append('designation', this.state.select_designation);
        formData.append('title', this.state.select_title);
        formData.append('office_number', this.state.office_no);
        formData.append('mobile_number', this.state.mobile_no);
        formData.append('home_number', this.state.home_no);
        formData.append('ext_number', this.state.extention_no);
        formData.append('email', this.state.email);
        formData.append('address', this.state.address);
        formData.append('city', this.state.city);
        formData.append('state', this.state.state);
        formData.append('postal_code', this.state.postal_code);
        formData.append('country', this.state.select_country);
        formData.append('industry', this.state.select_industry);
        formData.append('products_services', this.state.product_services);
        formData.append('website', this.state.website);
        formData.append('remarks', this.state.remarks);

        if (this.state.contact_id === null && this.state.contact_categ !== '' && this.state.company_id !== '') {

          showMessage({
            message: "",
            description: "Contact Id, Contact Type and Company Id must Be Added",
            type: "danger",
          });
        }

        else {
          fetch(apiBasePath, {
            method: 'POST',
            body: formData
          })

            .then(response => {
              if (response.status == 200) {

                return response.json();
              }
              else if (response.status == 101) {
                AsyncStorage.removeItem(Constant.api_token);
                this.props.navigation.navigate('SignUp');
              }
              else {
              }

            })
            .then(responseJson => {
              str = responseJson;

              if (str.status === true) {
                showMessage({
                  message: "",
                  description: "Contact successfully Updated",
                  type: "success",
                }.then(this.props.navigation.goBack(null)));

              }


            })
            .catch(error => {

              this.setState({ isLoading: false }, () => { });
            }
            )
        }
      }
      else {

        const api_token = await AsyncStorage.getItem(Constant.api_token);
        let formData = new FormData();

        formData.append('api_key', 'b4bc8f195a1c926b184f33a466bbc837689b33fe');
        formData.append('api_token', api_token);
        formData.append('method', 'update_sub_contact');
        formData.append('sub_contact_id', this.state.subContact_id);
        formData.append('first_name', this.state.sub_firstname);
        formData.append('last_name', this.state.sub_lastname);
        formData.append('company_name', this.state.sub_company_name);
        formData.append('designation', this.state.select_sub_designation);
        formData.append('title', this.state.sub_title);
        formData.append('office_number', this.state.sub_office_no);
        formData.append('mobile_number', this.state.sub_mobile_no);
        formData.append('home_number', this.state.sub_home_no);
        formData.append('ext_number', this.state.sub_extention_no);
        formData.append('email', this.state.subemail);
        formData.append('address', this.state.sub_address);
        formData.append('city', this.state.subcity);
        formData.append('state', this.state.subState);
        formData.append('postal_code', this.state.sub_postal_code);
        formData.append('country', this.state.select_sub_Country);
        formData.append('industry', this.state.select_sub_industry);
        formData.append('products_services', this.state.subtags);
        formData.append('website', this.state.sub_website);
        formData.append('remarks', this.state.sub_remarks);

        if (this.state.subContact_id === null) {

          showMessage({
            message: "",
            description: "Sub Contact Id must Be Added",
            type: "danger",
          });

        }
        else {
          fetch(apiBasePath, {
            method: 'POST',
            body: formData
          })

            .then(response => {
              if (response.status == 200) {
                return response.json();
              }
              else if (response.status == 101) {
                AsyncStorage.removeItem(Constant.api_token);
                this.props.navigation.navigate('SignUp');
              }
              else {
              }

            })
            .then(responseJson => {
              str = responseJson;

              if (str.status === true) {

                showMessage({
                  message: "",
                  description: "Subcontact successfully Updated",
                  type: "success",
                }.then(this.props.navigation.goBack(null)));
              }


            })
            .catch(error => {

              this.setState({ isLoading: false });
            }
            )
        }

      }
    }
    else {

      alert('Check Your Internet Connection and Try Again')

    }
  }

  // Add Sub Contact

  addSubContact = async () => {

    const isConnected = await NetworkUtils.isNetworkAvailable()

    if (isConnected) {

      const api_token = await AsyncStorage.getItem(Constant.api_token);
      let formData = new FormData();

      formData.append('api_key', 'b4bc8f195a1c926b184f33a466bbc837689b33fe');
      formData.append('api_token', api_token);
      formData.append('method', 'add_sub_contact');
      formData.append('contact_id', this.state.contact_id);
      formData.append('set_as_main', this.state.set_main);
      formData.append('first_name', this.state.firstname);
      formData.append('last_name', this.state.lastname);
      formData.append('company_name', this.state.company);
      formData.append('designation', this.state.select_designation);
      formData.append('title', this.state.select_title);
      formData.append('office_number', this.state.office_no);
      formData.append('mobile_number', this.state.mobile_no);
      formData.append('home_number', this.state.home_no);
      formData.append('ext_number', this.state.extention_no);
      formData.append('email', this.state.email);
      formData.append('address', this.state.address);
      formData.append('city', this.state.city);
      formData.append('state', this.state.state);
      formData.append('postal_code', this.state.postal_code);
      formData.append('country', this.state.select_country);
      formData.append('industry', this.state.select_industry);
      formData.append('products_services', this.state.product_services);
      formData.append('website', this.state.website);
      formData.append('remarks', this.state.remarks);


      fetch(apiBasePath, {
        method: 'POST',
        body: formData
      })

        .then(response => {
          if (response.status == 200) {

            return response.json();
          }
          else if (response.status == 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }
          else {
          }

        })
        .then(responseJson => {
          str = responseJson;

          if (str.status === true && str.set_as_main === false) {

            showMessage({
              message: "",
              description: "SubContact successfully Added",
              type: "success",
            });


          }

          else if (str.set_as_main === true && str.status === true) {

            showMessage({
              message: "",
              description: "SubContact successfully Added and set as Main Contact",
              type: "success",
            });


          }


        })
        .catch(error => {

          this.setState({ isLoading: false }, () => { });
        }
        )
    }

    else {

      alert('Check Your Internet Connection and Try Again')

    }

  }

  // Modify the Key of Sub Contact Data

  modifySubContactKey() {

    if (this.state.subContactData.length == 0 || this.state.subContactData === undefined || this.state.subContactData === 'null') {

    }
    else {

      var arr = this.state.subContactData;

      arr.map((val) => {

        var name = val.first_name;

        val.value = val.id;
        val.label = name;

        delete val.id
        delete val.first_name

      })
      this.setState({ subContactData: arr, sub_firstname: arr.name, sub_lastname: arr.last_name, subContactState: true, subContact_id: arr[0].value }, () => { this.getSubContactDetails() })

    }

  }

  // Toggle Visibility of Update App Notification prompt

  setOverlayVisible(visible) {

    this.setState({ isvisible: visible });

  }

  // Toggle Value of Switch recieve Marketing Switch

  toggleSwitch = (value) => {

    this.setState({ recieveMarketing: value })

  }

  toggleSwitchSetMain = (value) => {

    this.setState({ setmainTogglevalue: value }, () => {

      if (this.state.setmainTogglevalue === true) {
        this.setState({ set_main: 1 })
      }
      else if (this.state.setmainTogglevalue === false) {
        this.setState({ set_main: 0 })
      }
    })
  }

  // Set SubContact as mainContact

  setSubContactasMainContact = async () => {

    const isConnected = await NetworkUtils.isNetworkAvailable()

    if (isConnected) {

      const api_token = await AsyncStorage.getItem(Constant.api_token);
      let formData = new FormData();

      formData.append('api_key', 'b4bc8f195a1c926b184f33a466bbc837689b33fe');
      formData.append('api_token', api_token);
      formData.append('method', 'set_as_main_contact');
      formData.append('contact_id', this.state.contact_id);
      formData.append('sub_contact_id', this.state.subContact_id);



      fetch(apiBasePath, {
        method: 'POST',
        body: formData
      })

        .then(response => {
          if (response.status == 200) {
            return response.json();
          }
          else if (response.status == 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }
          else {
          }

        })
        .then(responseJson => {
          str = responseJson;
          // console.log(JSON.stringify(str))
          if (str.error === 101) {
            AsyncStorage.removeItem(Constant.api_token);
            this.props.navigation.navigate('SignUp');
          }

          else {

            showMessage({
              message: "",
              description: "Subcontact successfully Set as Main Contact",
              type: "success",
            });

          }
        })
        .catch(error => {

          this.setState({ isLoading: false }, () => { });
        }
        )
    }
    else {

      alert('Check Your Internet Connection and Try Again')

    }

  }

  render() {

    return (

      <KeyboardAwareScrollView keyboardShouldPersistTaps='handled' keyboardDismissMode='on-drag' enableResetScrollToCoords={false}>

        <View style={styles.main_container}>

          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps='handled' keyboardDismissMode='on-drag'>

            <SafeAreaView>

              <View style={{ backgroundColor: Colors.white_color, paddingStart: 16, paddingEnd: 16, }}>

                <Text style={[{ textAlign: 'right', marginTop: 16 }, font_style.font_medium]}>Total Deal Amount(Opportunities)</Text>
                <Text style={[{ textAlign: 'right', fontSize: 25, color: Colors.primaryColor }, font_style.font_medium]}>{(this.state.deal_amount_open === null) ? '$ ' : '$ ' + this.state.deal_amount_open}</Text>

                <View style={{ flexDirection: 'row', marginBottom: 16 }}>

                  <TouchableOpacity activeOpacity={1}
                    style={[{ backgroundColor: (this.state.selectedButton === 'EditProfile') ? "#35E7BD" : Colors.primaryColor, }, styles.contact_icon]}
                    onPress={() => { this.setState({ selectedButton: 'EditProfile', feature_comming_Soon: false }, () => { }) }}>

                    <Image source={require('./../assets/images/user.png')}
                      style={{ width: 20, height: 20, tintColor: Colors.white_color }} resizeMode="contain" />

                  </TouchableOpacity>

                  <TouchableOpacity activeOpacity={1}
                    style={[{ backgroundColor: (this.state.selectedButton === 'usb') ? "#35E7BD" : Colors.primaryColor, }, styles.contact_icon]}
                    onPress={() => {
                      this.setState({ selectedButton: 'usb', feature_comming_Soon: false }, () => {
                        this.props.navigation.navigate("Opportunity", { contactID: this.state.contact_id, companyID: this.state.company_id, contact_type: this.state.contact_categ, category: 0, selectedTopLayerButton: 'usb' })
                      })
                    }}>

                    <Image source={require('./../assets/images/usb.png')}
                      style={{ width: 20, height: 20, tintColor: Colors.white_color }} resizeMode="contain" />

                  </TouchableOpacity>

                  <TouchableOpacity activeOpacity={1}
                    style={[{ backgroundColor: (this.state.selectedButton === 'monitor') ? "#35E7BD" : Colors.primaryColor }, styles.contact_icon]}
                    onPress={() => {
                      this.setState({ selectedButton: 'usb', feature_comming_Soon: false }, () => {
                        this.props.navigation.navigate("Opportunity", { contactID: this.state.contact_id, companyID: this.state.company_id, contact_type: this.state.contact_categ, category: 1, selectedTopLayerButton: 'monitor' })
                      })
                    }}>
                    <Image source={require('./../assets/images/monitor.png')}
                      style={{ width: 20, height: 20, tintColor: Colors.white_color }} resizeMode="contain" />

                  </TouchableOpacity>

                  <TouchableOpacity activeOpacity={1}
                    style={[{ backgroundColor: (this.state.selectedButton === 'calender1') ? "#35E7BD" : Colors.primaryColor, }, styles.contact_icon]}
                    onPress={() => { this.setState({ selectedButton: 'calender1', feature_comming_Soon: true, feature_name: 'Calendars' }, () => { }) }} >

                    <Image source={require('./../assets/images/calender1.png')}
                      style={{ width: 24, height: 24, tintColor: Colors.white_color }} resizeMode="contain" />

                  </TouchableOpacity>

                  <TouchableOpacity activeOpacity={1}
                    style={[{ backgroundColor: (this.state.selectedButton === 'pie-chart') ? "#35E7BD" : Colors.primaryColor, }, styles.contact_icon]}
                    onPress={() => { this.setState({ selectedButton: 'pie-chart', feature_comming_Soon: true, feature_name: 'Sales' }, () => { }) }} >

                    <Image source={require('./../assets/images/pie-chart.png')}
                      style={{ width: 20, height: 20, tintColor: Colors.white_color }} resizeMode="contain" />

                  </TouchableOpacity>

                  <TouchableOpacity activeOpacity={1}
                    style={[{ backgroundColor: (this.state.selectedButton === 'Forma_1') ? "#35E7BD" : Colors.primaryColor, }, styles.contact_icon]}
                    onPress={() => { this.setState({ selectedButton: 'Forma_1', feature_comming_Soon: true, feature_name: 'Data' }, () => { }) }}>

                    <Image source={require('./../assets/images/Forma_1.png')}
                      style={{ width: 36, height: 36, tintColor: Colors.white_color }} resizeMode="contain" />

                  </TouchableOpacity>

                  <TouchableOpacity activeOpacity={1}
                    style={[{ backgroundColor: (this.state.selectedButton === 'bell') ? "#35E7BD" : Colors.primaryColor, }, styles.contact_icon]}
                    onPress={() => { this.setState({ selectedButton: 'bell', feature_comming_Soon: true, feature_name: 'Updates' }, () => { }) }} >

                    <Image source={require('./../assets/images/bell.png')}
                      style={{ width: 20, height: 20, tintColor: Colors.white_color }} resizeMode="contain" />

                  </TouchableOpacity>

                </View>

              </View>

              {(this.state.feature_comming_Soon) ?

                <TouchableOpacity activeOpacity={0} onPress={() => { this.setState({ feature_comming_Soon: false }) }}>

                  <View style={{ justifyContent: 'center', alignItems: 'flex-start', alignContent: 'center', marginLeft: 16, marginBottom: 16 }}>

                    <Text style={[styles.large_text_style], { fontSize: 18, fontWeight: '500', marginTop: 16 }}>{this.state.feature_name}</Text>

                    <Text style={[styles.large_text_style]}>New Feature Coming Soon..</Text>


                  </View>

                </TouchableOpacity>

                :
                null

              }

              {/* Main Contact and Sub Contact Tab Portion */}

              <View style={{ marginTop: 10, backgroundColor: Colors.white_color, paddingTop: 2, paddingBottom: 20 }}>

                <View style={{ backgroundColor: Colors.white_color, padding: 16 }}>

                  <View style={{ backgroundColor: Colors.primaryColor, height: 46, borderRadius: 46 / 2, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', padding: 2 }}>

                    <TouchableOpacity activeOpacity={1}
                      onPress={() => { this.setState({ selectedTab: 0 }), () => { (tabvalue === 1) ? tabvalue = 0 : null } }}
                      style={[{ flex: 1, height: 42, justifyContent: 'center' }, this.state.selectedTab === 0 ? { backgroundColor: Colors.white_color, borderRadius: 42 / 2, } : {}]}>

                      <Text style={[styles.tab_text, font_style.font_medium, this.state.selectedTab === 0 ? { color: Colors.primaryColor } : { color: Colors.white_color }]}>Main Contact</Text>

                    </TouchableOpacity>

                    <TouchableOpacity activeOpacity={1}
                      onPress={() => { this.setState({ selectedTab: 1 }), this.getSubContact(); }}
                      style={[{ flex: 1, height: 42, justifyContent: 'center' }, this.state.selectedTab === 1 ? { backgroundColor: Colors.white_color, borderRadius: 42 / 2, } : {}]}>

                      <Text style={[styles.tab_text, font_style.font_medium, this.state.selectedTab === 1 ? { color: Colors.primaryColor } : { color: Colors.white_color }]}>Sub Contact</Text>

                    </TouchableOpacity>

                  </View>

                </View>

                {

                  // Field of Contact profile Detail Portion Started from here

                  (!this.state.selectedTab) ?

                    <View style={{ paddingStart: 16, paddingEnd: 16 }}>

                      <Text style={[styles.text_style1]}>Title:</Text>

                      <View activeOpacity={0} style={styles.followTimeRectangle3, { marginLeft: -7, flexDirection: 'row', backgroundColor: '#ffff' }}>

                        <ImageBackground source={require('../assets/images/Rectangle_14.png')} style={{ width: '101%', height: '100%', }} resizeMode='cover'>

                          <View style={styles.img_view}>

                            <Image source={require('../assets/images/arrow_down.png')} style={[styles.top_image_style, { tintColor: Colors.white_color, marginTop: 18, marginEnd: 10 }]} resizeMode="contain" />

                          </View>

                          <Dropdown
                            containerStyle={styles.dropdown_container}
                            pickerStyle={{
                              width: '92%', marginTop: 60, marginStart: 17, paddingStart: 17, shadowColor: 'rgba(0, 0, 0, 0.24)',
                              shadowOffset: { width: 2, height: -4 },
                              shadowRadius: 21,
                              borderRadius: 46 / 2,
                              backgroundColor: '#ffffff'
                            }}
                            inputContainerStyle={{
                              marginLeft: 26,
                              borderBottomColor: 'transparent',
                              justifyContent: 'center',
                            }}
                            selectedItemColor='#222222'
                            textColor='#ffffff'
                            itemColor='#222222'
                            baseColor='#ffffff00'
                            dropdownPosition={0}
                            itemCount={5}
                            dropdownOffset={{ top: 10, bottom: -10 }}
                            dropdownMargins={{ min: 0, max: 0 }}
                            data={(this.state.DataState) ? this.state.title : []}
                            value={this.state.select_title}
                            onChangeText={(value) => { this.setState({ select_title: value }) }}
                          />

                        </ImageBackground>

                      </View>

                      <Text style={[styles.text_style1]}>First Name:</Text>

                      <TextInput
                        style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                        onChangeText={(value) => this.setState({ firstname: value })}
                        value={this.state.firstname}
                        placeholderTextColor={Colors.black_color}
                      />

                      <Text style={[styles.text_style1]}>Last Name:</Text>

                      <TextInput
                        style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                        onChangeText={(value) => this.setState({ lastname: value })}
                        value={this.state.lastname}
                        placeholderTextColor={Colors.black_color}
                      />

                      <Text style={[styles.text_style1]}>Office Number:</Text>

                      <TextInput
                        style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                        onChangeText={(value) => this.setState({ office_no: value })}
                        value={this.state.office_no}
                        placeholderTextColor={Colors.black_color}
                        keyboardType='numeric'
                      />

                      <Text style={[styles.text_style1]}>Extention Number:</Text>

                      <TextInput
                        style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                        onChangeText={(value) => this.setState({ extention_no: value })}
                        value={this.state.extention_no}
                        placeholderTextColor={Colors.black_color}
                        keyboardType='numeric'
                      />

                      <Text style={[styles.text_style1]}>Mobile Number:</Text>

                      <TextInput
                        style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                        onChangeText={(value) => this.setState({ mobile_no: value })}
                        value={this.state.mobile_no}
                        placeholderTextColor={Colors.black_color}
                        keyboardType='numeric'
                      />

                      <Text style={[styles.text_style1]}>Home Number:</Text>

                      <TextInput
                        style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                        onChangeText={(value) => this.setState({ home_no: value })}
                        value={this.state.home_no}
                        placeholderTextColor={Colors.black_color}
                        keyboardType='numeric'
                      />

                      <Text style={[styles.text_style1]}>Email:</Text>

                      <TextInput
                        style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                        onChangeText={(value) => this.setState({ email: value })}
                        value={this.state.email}
                        placeholderTextColor={Colors.black_color}
                      />

                      <Text style={[styles.text_style1]}>Address:</Text>

                      <View style={{ marginTop: 5, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                        <TextInput
                          style={[{ height: 100, textAlignVertical: 'top', color: '#222222', marginTop: 10, marginLeft: 16, fontSize: 14 }]}
                          onChangeText={(value) => this.setState({ address: value })}
                          value={this.state.address}
                          multiline={true}
                          placeholderTextColor='#222222'
                        />

                      </View>

                      <Text style={[styles.text_style1]}>City:</Text>

                      <View style={{ marginTop: 5, height: 42, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                        <TextInput
                          style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                          onChangeText={(value) => this.setState({ city: value })}
                          value={this.state.city}
                          placeholderTextColor={Colors.black_color}
                        />

                      </View>

                      <Text style={[styles.text_style1]}>State:</Text>

                      <View style={{ marginTop: 5, height: 42, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                        <TextInput
                          style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                          onChangeText={(value) => this.setState({ state: value })}
                          value={this.state.state}
                          placeholderTextColor={Colors.black_color}
                        />

                      </View>

                      <Text style={[styles.text_style1]}>Country:</Text>

                      <View activeOpacity={1} style={[styles.dropdown_view, { marginTop: 4 }]}>

                        <View style={styles.img_view}>

                          <Image source={require('../assets/images/arrow_down.png')} style={[styles.top_image_style, { tintColor: Colors.black_color }]} resizeMode="contain" />

                        </View>

                        <Dropdown
                          containerStyle={styles.dropdown_container}
                          pickerStyle={{
                            width: '92%', marginLeft: 16, marginTop: 60, marginStart: 17, paddingStart: 17, shadowColor: 'rgba(0, 0, 0, 0.24)',
                            shadowOffset: { width: 2, height: -4 },
                            shadowRadius: 21,
                            borderRadius: 46 / 2,
                            backgroundColor: '#ffffff',
                          }}
                          inputContainerStyle={{
                            marginLeft: 20,
                            borderBottomColor: 'transparent',
                            justifyContent: 'center',
                          }}
                          textColor='#222222'
                          itemColor='#222222'
                          baseColor='#ffffff00'
                          dropdownPosition={0}
                          itemCount={5}
                          dropdownOffset={{ top: 10, bottom: -10 }}
                          dropdownMargins={{ min: 0, max: 0 }}
                          data={(this.state.DataState) ? this.state.Country : []}
                          value={(this.state.ProfileData.country === null || this.state.ProfileData.country === undefined) ? '' : this.state.ProfileData.country}
                          onChangeText={(value) => { this.setState({ select_country: value }) }}
                        />

                      </View>

                      <Text style={[styles.text_style1]}>Postal Code:</Text>

                      <TextInput
                        style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                        onChangeText={(value) => this.setState({ postal_code: value })}
                        value={this.state.postal_code}
                        placeholder={this.state.postal_code}
                        placeholderTextColor={Colors.black_color}
                        keyboardType='numeric'
                      />

                      <Text style={[styles.text_style1]}>Company:</Text>

                      <TextInput
                        style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                        onChangeText={(value) => this.setState({ company: value })}
                        value={this.state.company}
                        placeholder={this.state.ProfileData.company_name}
                        placeholderTextColor={Colors.black_color}
                      />

                      <Text style={[styles.text_style1]}>Website:</Text>

                      <TextInput
                        style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                        onChangeText={(value) => this.setState({ website: value })}
                        value={(this.state.website === "null") ? ' ' : this.state.website}
                        placeholder={(this.state.ProfileData.website === 'null') ? ' ' : this.state.ProfileData.website}
                        placeholderTextColor={Colors.black_color}
                      />

                      <Text style={[styles.text_style1]}>Designation:</Text>

                      <View activeOpacity={1} style={[styles.dropdown_view, { marginTop: 4 }]}>

                        <View style={styles.img_view}>

                          <Image source={require('../assets/images/arrow_down.png')} style={[styles.top_image_style, { tintColor: Colors.black_color }]} resizeMode="contain" />

                        </View>

                        <Dropdown
                          containerStyle={styles.dropdown_container}
                          pickerStyle={{
                            width: '92%', marginTop: 60, paddingStart: 17, shadowColor: 'rgba(0, 0, 0, 0.24)',
                            shadowOffset: { width: 2, height: -4 },
                            shadowRadius: 21,
                            borderRadius: 46 / 2,
                            backgroundColor: '#ffffff',
                          }}
                          inputContainerStyle={{
                            marginLeft: 20,
                            borderBottomColor: 'transparent',
                            justifyContent: 'center',
                          }}
                          textColor='#222222'
                          itemColor='#222222'
                          baseColor='#ffffff00'
                          dropdownPosition={0}
                          itemCount={5}
                          dropdownOffset={{ top: 10, bottom: -10, left: 0 }}
                          dropdownMargins={{ min: 0, max: 0 }}
                          data={(this.state.DataState) ? this.state.designation : []}
                          value={this.state.ProfileData.designation}
                          onChangeText={(value) => { this.setState({ select_designation: value }) }}
                        />

                      </View>

                      <Text style={[styles.text_style1]}>Industry:</Text>

                      <View activeOpacity={1} style={[styles.dropdown_view, { marginTop: 4 }]}>

                        <View style={styles.img_view}>

                          <Image source={require('../assets/images/arrow_down.png')} style={[styles.top_image_style, { tintColor: Colors.black_color }]} resizeMode="contain" />

                        </View>

                        <Dropdown
                          containerStyle={styles.dropdown_container}
                          pickerStyle={{
                            width: '92%', marginLeft: 16, marginTop: 60, marginStart: 17, paddingStart: 17, shadowColor: 'rgba(0, 0, 0, 0.24)',
                            shadowOffset: { width: 2, height: -4 },
                            shadowRadius: 21,
                            borderRadius: 46 / 2,
                            backgroundColor: '#ffffff',
                          }}
                          inputContainerStyle={{
                            marginLeft: 20,
                            borderBottomColor: 'transparent',
                            justifyContent: 'center',
                          }}
                          textColor='#222222'
                          itemColor='#222222'
                          baseColor='#ffffff00'
                          dropdownPosition={0}
                          itemCount={5}
                          dropdownOffset={{ top: 10, bottom: -10 }}
                          dropdownMargins={{ min: 0, max: 0 }}
                          data={(this.state.DataState) ? this.state.industry : []}
                          value={this.state.ProfileData.industry}
                          onChangeText={(value) => { this.setState({ select_industry: value }) }}
                        />

                      </View>

                      <Text style={[styles.text_style1]}>Product &amp; Services:</Text>

                      <TagInput
                        style={{
                          width: '103%', color: '#222222', height: 42, fontSize: 14, fontWeight: '400',
                          marginLeft: -7,
                          paddingStart: 16,
                          borderRadius: 21,
                          backgroundColor: Colors.white_shade,
                          fontFamily: 'Helvetica-Light',
                        }}
                        label='Enter Tags Here'
                        updateState={this.updateTagState}
                        tags={this.state.tags}
                        tagStyle={styles.tag}
                      />

                      <Text style={[styles.text_style1]}>Receive Marketing:</Text>

                      <View style={{ height: 24, marginBottom: 10, }}>

                        <Switch
                          trackColor={{ true: Colors.primaryColor, false: Colors.white_color }}
                          style={{ marginTop: 4, height: 24, }}
                          onValueChange={(value) => this.toggleSwitch(value)}
                          value={this.state.recieveMarketing}
                        />

                      </View>

                      <Text style={[styles.text_style1]}>Remarks:</Text>

                      <View style={{ marginTop: 5, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                        <TextInput
                          style={[textInput.gray_textInput, { height: 100, textAlignVertical: 'top', color: '#222222', marginTop: 10, fontSize: 14 }]}
                          onChangeText={(value) => this.setState({ remarks: value })}
                          value={this.state.remarks}
                          placeholder='Enter Remarks'
                          multiline={true}
                          placeholderTextColor={Colors.black_color}
                        />

                      </View>

                    </View>

                    :

                    // Field of Sub Contact List and Sub Contact profile Detail Portion Started from here

                    <View style={{ marginTop: 10, backgroundColor: Colors.white_color, paddingTop: 16, paddingBottom: 20, paddingStart: 16, paddingEnd: 16 }}>

                      <Text style={[{ fontSize: 20, color: Colors.black_color, marginTop: 8 }, font_style.font_medium]}>Sub Contact</Text>
                      <Text style={[{ marginTop: 8, marginBottom: 8 }, font_style.font_light]}>Select Contact:</Text>

                      <View activeOpacity={1}
                        style={[{ backgroundColor: Colors.white_shade, marginBottom: 10 }, styles.dropdown_view,]}>

                        <View style={styles.img_view}>

                          <Image source={require('../assets/images/arrow_down.png')} style={[styles.top_image_style, { tintColor: Colors.black_color }]} resizeMode="contain" />

                        </View>

                        <Dropdown
                          containerStyle={styles.dropdown_container}
                          pickerStyle={{
                            width: '92%', marginTop: 60, paddingStart: 14, shadowColor: 'rgba(0, 0, 0, 0.24)',
                            shadowOffset: { width: 2, height: -4 },
                            shadowRadius: 21,

                            borderRadius: 46 / 2,
                            backgroundColor: '#ffffff',
                          }}
                          inputContainerStyle={{
                            marginLeft: 20,
                            borderBottomColor: 'transparent',
                            justifyContent: 'center',
                          }}
                          textColor='#222222'
                          itemColor='#222222'
                          baseColor='#ffffff00'
                          dropdownPosition={0}
                          itemCount={5}
                          dropdownOffset={{ top: 10, bottom: -10, left: 0 }}
                          dropdownMargins={{ min: 0, max: 0 }}
                          data={(this.state.subContactState) ? this.state.subContactData : []}
                          value={this.state.subContact_id}
                          onChangeText={(value) => { this.setState({ subContact_id: value }, () => { this.getSubContactDetails() }) }}
                        />

                      </View>

                      <View style={{ height: 46, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', padding: 2 }}>

                        <TouchableOpacity activeOpacity={1} onPress={() => { this.setState({ selectedTab: 0 }, () => { this.addSubContact() }) }}
                          style={[{ flex: 1, height: 42, justifyContent: 'center', backgroundColor: Colors.green_start, borderRadius: 42 / 2, marginEnd: 8 }]}>

                          <Text style={[styles.tab_text, font_style.font_medium, { color: Colors.white_color }]}>Add Contact</Text>

                        </TouchableOpacity>

                        <TouchableOpacity activeOpacity={1} onPress={() => { this.setState({ selectedTab: 1 }, () => { this.setSubContactasMainContact() }) }}
                          style={[{ flex: 1, height: 42, justifyContent: 'center', backgroundColor: Colors.primaryColor, borderRadius: 42 / 2, marginStart: 8 }]}>

                          <Text style={[styles.tab_text, font_style.font_medium, { color: Colors.white_color }]}>Set as Main Contact</Text>

                        </TouchableOpacity>

                      </View>



                      <View>

                        <Text style={[styles.text_style1]}>Set As Main:</Text>


                        <View style={{ marginTop: 10, height: 24, marginBottom: 10, }}>

                          <Switch
                            trackColor={{ true: Colors.primaryColor, false: Colors.white_color }}
                            style={{ height: 20, width: 40, }}
                            onValueChange={(value) => this.toggleSwitchSetMain(value)}
                            value={this.state.setmainTogglevalue}
                          />

                        </View>

                        <Text style={[styles.text_style1]}>Title:</Text>

                        <View activeOpacity={1} style={[styles.dropdown_view]}>

                          <View style={styles.img_view}>

                            <Image source={require('../assets/images/arrow_down.png')} style={[styles.top_image_style, { tintColor: Colors.black_color }]} resizeMode="contain" />

                          </View>

                          <Dropdown
                            containerStyle={styles.dropdown_container}
                            pickerStyle={{
                              width: '92%', backgroundColor: Colors.primaryColor, marginLeft: 16, marginTop: 60, paddingStart: 17, shadowColor: 'rgba(0, 0, 0, 0.24)',
                              shadowOffset: { width: 2, height: -4 },
                              shadowRadius: 21,
                              borderRadius: 46 / 2,
                              backgroundColor: '#ffffff',
                            }}
                            inputContainerStyle={{
                              marginLeft: 20,
                              borderBottomColor: 'transparent',
                              justifyContent: 'center',
                            }}
                            selectedItemColor='#222222'
                            textColor={'#222222'}
                            itemColor='#222222'
                            baseColor='#ffffff00'
                            dropdownOffset={{ top: 10, bottom: 0 }}
                            dropdownPosition={0}
                            itemCount={5}
                            dropdownMargins={{ min: 0, max: 0 }}
                            data={(this.state.subContactState) ? this.state.title : []}
                            value={this.state.sub_title}
                            onChangeText={(value) => { this.setState({ sub_title: value }) }}
                          />

                        </View>

                        <Text style={[styles.text_style1]}>First Name:</Text>

                        <View style={{ marginTop: 5, height: 42, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                          <TextInput
                            style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                            onChangeText={(value) => this.setState({ sub_firstname: value })}
                            value={this.state.sub_firstname}
                            placeholderTextColor={Colors.black_color}
                          />

                        </View>

                        <Text style={[styles.text_style1]}>Last Name:</Text>

                        <View style={{ marginTop: 5, height: 42, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                          <TextInput
                            style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                            onChangeText={(value) => this.setState({ sub_lastname: value })}
                            value={this.state.sub_lastname}
                            placeholderTextColor={Colors.black_color}
                          />

                        </View>

                        <Text style={[styles.text_style1]}>Office Number:</Text>

                        <TextInput
                          style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                          onChangeText={(value) => this.setState({ sub_office_no: value })}
                          value={this.state.sub_office_no}
                          placeholderTextColor={Colors.black_color}
                          keyboardType='numeric'
                        />

                        <Text style={[styles.text_style1]}>Extention Number:</Text>

                        <TextInput
                          style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                          onChangeText={(value) => this.setState({ sub_extention_no: value })}
                          value={this.state.sub_extention_no}
                          placeholderTextColor={Colors.black_color}
                          keyboardType='numeric'
                        />
                        <Text style={[styles.text_style1]}>Home Number:</Text>

                        <TextInput
                          style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                          onChangeText={(value) => this.setState({ sub_home_no: value })}
                          value={this.state.sub_home_no}
                          placeholderTextColor={Colors.black_color}
                          keyboardType='numeric'
                        />

                        <Text style={[styles.text_style1]}>Mobile Number:</Text>

                        <TextInput
                          style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                          onChangeText={(value) => this.setState({ sub_mobile_no: value })}
                          value={this.state.sub_mobile_no}
                          placeholderTextColor={Colors.black_color}
                          keyboardType='numeric'
                        />

                        <Text style={[styles.text_style1]}>Email:</Text>

                        <View style={{ marginTop: 5, height: 42, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                          <TextInput
                            style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                            onChangeText={(value) => this.setState({ subemail: value })}
                            value={this.state.subemail}
                            placeholder={this.state.subContactDetail.subemail}
                            placeholderTextColor={Colors.black_color}
                          />

                        </View>

                        <Text style={[styles.text_style1]}>Address:</Text>

                        <View style={{ marginTop: 5, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                          <TextInput
                            style={[{ height: 100, textAlignVertical: 'top', color: '#222222', marginTop: 10, marginLeft: 16, fontSize: 14 }]}
                            onChangeText={(value) => this.setState({ sub_address: value })}
                            value={this.state.sub_address}
                            multiline={true}
                            placeholderTextColor='#222222'
                          />

                        </View>

                        <Text style={[styles.text_style1]}>City:</Text>

                        <View style={{ marginTop: 5, height: 42, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                          <TextInput
                            style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                            onChangeText={(value) => this.setState({ subcity: value })}
                            value={this.state.subcity}
                            placeholderTextColor={Colors.black_color}
                          />

                        </View>

                        <Text style={[styles.text_style1]}>State:</Text>

                        <View style={{ marginTop: 5, height: 42, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                          <TextInput
                            style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                            onChangeText={(value) => this.setState({ subState: value })}
                            value={this.state.subState}
                            placeholderTextColor={Colors.black_color}
                          />

                        </View>

                        <Text style={[styles.text_style1]}>Country:</Text>

                        <View activeOpacity={1} style={[styles.dropdown_view, { marginTop: 4 }]}>

                          <View style={styles.img_view}>

                            <Image source={require('../assets/images/arrow_down.png')} style={[styles.top_image_style, { tintColor: Colors.black_color }]} resizeMode="contain" />

                          </View>

                          <Dropdown
                            containerStyle={styles.dropdown_container}
                            pickerStyle={{
                              width: '92%', marginLeft: 16, marginTop: 60, marginStart: 17, paddingStart: 17, shadowColor: 'rgba(0, 0, 0, 0.24)',
                              shadowOffset: { width: 2, height: -4 },
                              shadowRadius: 21,
                              borderRadius: 46 / 2,
                              backgroundColor: '#ffffff',
                            }}
                            inputContainerStyle={{
                              marginLeft: 20,
                              borderBottomColor: 'transparent',
                              justifyContent: 'center',
                            }}
                            selectedItemColor='#222222'
                            textColor={'#222222'}
                            itemColor='#222222'
                            baseColor='#ffffff00'
                            dropdownOffset={{ top: 10, bottom: 0 }}
                            dropdownPosition={0}
                            itemCount={5}
                            dropdownMargins={{ min: 0, max: 0 }}
                            data={(this.state.subContactState) ? this.state.Country : []}
                            value={(this.state.subContactState) ? this.state.subContactDetail.country : ''}
                            onChangeText={(value) => { this.setState({ select_sub_Country: value }) }}
                          />

                        </View>

                        <Text style={[styles.text_style1]}>Postal Code:</Text>

                        <TextInput
                          style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                          onChangeText={(value) => this.setState({ sub_postal_code: value })}
                          value={(this.state.sub_postal_code === undefined || this.state.sub_postal_code === null) ? '' : this.state.sub_postal_code}
                          placeholderTextColor={Colors.black_color}
                          keyboardType='numeric'
                        />

                        <Text style={[styles.text_style1]}>Company:</Text>

                        <TextInput
                          style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                          onChangeText={(value) => this.setState({ sub_company_name: value })}
                          value={this.state.sub_company_name}
                          placeholder={this.state.subContactDetail.company_name}
                          placeholderTextColor={Colors.black_color}
                        />

                        <Text style={[styles.text_style1]}>Website:</Text>

                        <TextInput
                          style={[textInput.gray_textInput, { color: '#222222', marginTop: 4, height: 42, fontSize: 14, fontWeight: '400', }]}
                          onChangeText={(value) => this.setState({ sub_website: value })}
                          value={(this.state.sub_website) ? ' ' : this.state.sub_website}
                          // placeholder={this.state.subContactDetail.sub_website}
                          placeholderTextColor={Colors.black_color}
                        />

                        <Text style={[styles.text_style1]}>Designation:</Text>

                        <View activeOpacity={1} style={[{}, styles.dropdown_view, { marginTop: 4 }]}>

                          <View style={styles.img_view}>

                            <Image source={require('../assets/images/arrow_down.png')} style={[styles.top_image_style, { tintColor: Colors.black_color }]} resizeMode="contain" />

                          </View>

                          <Dropdown
                            containerStyle={styles.dropdown_container}
                            pickerStyle={{
                              width: '92%', marginTop: 60, paddingStart: 17, shadowColor: 'rgba(0, 0, 0, 0.24)',
                              shadowOffset: { width: 2, height: -4 },
                              shadowRadius: 21,
                              borderRadius: 46 / 2,
                              backgroundColor: '#ffffff',
                            }}
                            inputContainerStyle={{
                              marginLeft: 20,
                              borderBottomColor: 'transparent',
                              justifyContent: 'center',
                            }}
                            textColor={'#222222'}
                            itemColor='#222222'
                            selectedItemColor='#222222'
                            baseColor='#ffffff00'
                            dropdownOffset={{ top: 10, bottom: 0 }}
                            dropdownPosition={0}
                            itemCount={5}
                            dropdownMargins={{ min: 0, max: 0 }}
                            data={(this.state.subContactState) ? this.state.designation : []}
                            value={(this.state.subContactState) ? this.state.subContactDetail.designation : ''}
                            onChangeText={(value) => { this.setState({ sub_designation: value }) }}
                          />

                        </View>

                        <Text style={[styles.text_style1]}>Industry:</Text>

                        <View activeOpacity={1} style={[styles.dropdown_view, { marginTop: 4 }]}>

                          <View style={styles.img_view}>

                            <Image source={require('../assets/images/arrow_down.png')} style={[styles.top_image_style, { tintColor: Colors.black_color }]} resizeMode="contain" />

                          </View>

                          <Dropdown
                            containerStyle={styles.dropdown_container}
                            pickerStyle={{
                              width: '92%', marginLeft: 16, marginTop: 60, marginStart: 17, paddingStart: 17, shadowColor: 'rgba(0, 0, 0, 0.24)',
                              shadowOffset: { width: 2, height: -4 },
                              shadowRadius: 21,
                              borderRadius: 46 / 2,
                              backgroundColor: '#ffffff',
                            }}
                            inputContainerStyle={{
                              marginLeft: 20,
                              borderBottomColor: 'transparent',
                              justifyContent: 'center',
                            }}
                            textColor={'#222222'}
                            itemColor='#222222'
                            selectedItemColor='#222222'
                            baseColor='#ffffff00'
                            dropdownOffset={{ top: 10, bottom: 0 }}
                            dropdownPosition={0}
                            itemCount={5}
                            dropdownMargins={{ min: 0, max: 0 }}
                            data={(this.state.subContactState) ? this.state.industry : []}
                            value={(this.state.subContactState) ? this.state.subContactDetail.industry : ''}
                            onChangeText={(value) => { this.setState({ select_sub_industry: value }) }}
                          />

                        </View>

                        <Text style={[styles.text_style1]}>Product &amp; Services:</Text>

                        <TagInput
                          style={{
                            width: '103%', color: '#222222', fontSize: 14, fontWeight: '400',
                            marginLeft: -7,
                            paddingTop: 10,
                            paddingStart: 10,
                            borderRadius: 21,
                            backgroundColor: Colors.white_shade,
                            fontFamily: 'Helvetica-Light',
                          }}
                          label='Enter Products and services Here'
                          updateState={this.updateSubTagState}
                          tags={this.state.subtags}
                          tagStyle={styles.tag}
                        />

                        <Text style={[styles.text_style1]}>Remarks:</Text>

                        <View style={{ marginTop: 5, borderRadius: 42 / 2, backgroundColor: Colors.white_shade, }}>

                          <TextInput
                            style={[textInput.gray_textInput, { height: 100, textAlignVertical: 'top', color: '#222222', marginTop: 10, fontSize: 14 }]}
                            onChangeText={(value) => this.setState({ sub_remarks: value })}
                            value={this.state.sub_remarks}
                            placeholder='Enter Remarks'
                            multiline={true}
                            placeholderTextColor={Colors.black_color}
                          />

                        </View>

                      </View>

                    </View>
                }

              </View>

            </SafeAreaView>

          </ScrollView>

          {/* Overlay for Update App Notification Prompt */}

          <Overlay
            isVisible={this.state.isvisible}
            windowBackgroundColor="rgba(0, 0, 0, 0.5)"
            overlayBackgroundColor="white"
            width="80%"
            height="35%"
          >

            <View style={{ marginTop: 30 }}>

              <Text style={styles.pleaseUpdate}>Please update Your app to Continue</Text>
              <Text style={styles.thisApp}>This app version 10.0.3.1 is no longer Supported.</Text>

              <TouchableOpacity>

                <View style={[styles.Update_now]}>

                  <Image source={require('../assets/images/Update_Now_bg.png')} style={styles.UpdateImage_Style} resizeMode="cover"></Image>

                  <Text style={[styles.updateNowtext]}>Update Now</Text>

                </View>

              </TouchableOpacity>

              <TouchableOpacity onPress={() => { this.setOverlayVisible(false); }}>

                <Text style={[styles.cancel_txt, font_style.font_medium,]}>Cancel</Text>

              </TouchableOpacity>

            </View>

          </Overlay>

        </View>

      </KeyboardAwareScrollView>
    );
  }

}


// Styling Code for UI Elements

const styles = StyleSheet.create({

  top_layout: {

    paddingRight: 20,
    paddingLeft: 20

  },
  top_layout1: {

    paddingTop: 5,
    paddingRight: 20,
    paddingLeft: 20

  },

  multiSelectContainer: {

    height: 400,
    width: '80%',
    backgroundColor: '#0000'

  },

  main_container: {

    flex: 1,
    backgroundColor: Colors.white_color,

  },

  container: {

    flex: 1,
    backgroundColor: Colors.bg_color,

  },

  searchInput: {

    height: 50,
    borderColor: '#f2f2f2',
    borderWidth: 1,
    paddingLeft: 10,
    backgroundColor: '#fff'

  },

  listItem: {

    width: '100%',
    flexDirection: 'row',
    height: 55,
    paddingLeft: 10,
    paddingRight: 10,
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: '#e5e5e5',

  },

  listItemText: {

    fontSize: 14

  },

  tag: {

    backgroundColor: Colors.primaryColor,
    color: Colors.white_color,

  },

  btn_view: {

    backgroundColor: Colors.primaryColor,
    height: 32,
    borderRadius: 32 / 2,
    alignItems: 'center',
    justifyContent: 'center',
    paddingStart: 16,
    paddingEnd: 16

  },

  txt_view: {

    color: Colors.white_color,
    fontSize: 14,
    textAlign: 'center',
    fontFamily: 'HelveticaNeue-Medium'

  },

  contact_icon: {

    width: 42,
    height: 42,
    borderRadius: 42 / 2,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 4

  },

  followTimeRectangle3: {

    height: 46,
    width: '100%',
    borderRadius: 46 / 2,
    alignContent: 'center',
    borderStyle: 'solid',
    borderWidth: 2,

  },

  margin_style: {

    marginStart: 16,
    marginEnd: 16

  },

  img_view: {

    alignSelf: 'flex-end',
    position: 'absolute',
    paddingEnd: 16

  },

  top_image_style: {

    width: 16, height: 16,
    tintColor: Colors.black_color,
    alignItems: 'flex-end',
    justifyContent: 'center',

  },

  dropdown_container: {

    width: '100%',
    alignSelf: 'center',
    paddingTop: 4,

  },
  large_text_style: {
    width: '65%',
    flex: 1,
    marginTop: 10,
    color: '#222222',
    fontFamily: 'Helvetica Neue',
    fontSize: 18,
    fontWeight: '400',

  },

  dropdown_view: {

    height: 42,
    justifyContent: 'center',
    backgroundColor: Colors.white_shade,
    borderRadius: 42 / 2, paddingEnd: 16

  },

  dropdown_view1: {

    flex: 1,
    height: 42,
    justifyContent: 'center',
    backgroundColor: Colors.primaryColor,
    borderRadius: 42 / 2, paddingEnd: 16,
    marginTop: 8,
    marginBottom: 16

  },

  text_style1: {

    marginTop: 10,
    color: '#222222',
    fontFamily: 'Helvetica Neue',
    fontSize: 14,
    fontWeight: '400',

  },

  text_style: {

    fontSize: 14,
    fontFamily: 'Helvetica-Light'

  },

  circle_view: {

    width: 20, height: 20,
    marginEnd: 4,
    borderColor: Colors.primaryColor,
    borderRadius: 20 / 2,
    borderWidth: 1

  },

  checkbox_img: {

    width: 20, height: 20, marginEnd: 4,
    tintColor: Colors.primaryColor,
    shadowOffset: { width: 2, height: 2, },
    shadowColor: Colors.primaryColor,
    shadowOpacity: .2,
    shadowRadius: 20 / 2,
    elevation: 3,

  },

  tab_text: {

    fontSize: 16,
    color: Colors.primaryColor,
    textAlign: 'center'

  },

  pleaseUpdate: {

    marginLeft: 20,
    marginEnd: 20,
    justifyContent: 'flex-start',
    textAlign: 'center',
    color: '#222222',
    fontFamily: 'Helvetica Neue',
    fontSize: 22,
    fontWeight: '500',

  },

  thisApp: {

    marginLeft: 20,
    marginTop: 20,
    marginEnd: 20,
    justifyContent: 'center',
    textAlign: 'center',
    color: '#5d5d5d',
    fontFamily: 'Helvetica Neue',
    fontSize: 18,
    fontWeight: '400',

  },

  Update_now: {

    width: 150,
    height: 56,
    alignSelf: 'center',
    marginTop: 20,
    borderRadius: 56 / 2,
    backgroundColor: '#f0ab16',

  },

  UpdateImage_Style: {

    flex: 1,
    position: 'absolute',
    width: 150,
    height: 56,
    borderRadius: 56,
    backgroundColor: '#f0ab16',

  },

  updateNowtext: {

    flex: 1,
    marginTop: 18,
    textAlign: 'center',
    alignContent: 'center',
    justifyContent: 'center',
    color: '#ffffff',
    fontFamily: 'Helvetica Neue',
    fontSize: 16,
    fontWeight: '500',

  },

  cancel_txt: {

    marginTop: 20,
    color: '#f566a5',
    fontFamily: 'Helvetica Neue',
    fontSize: 20,
    fontWeight: '500',
    textAlign: 'center',
    marginBottom: 30,

  },

});
